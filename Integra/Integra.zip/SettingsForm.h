#pragma once

namespace Integra {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// ������ ��� SettingsForm
	/// </summary>
	public ref class SettingsForm : public System::Windows::Forms::Form
	{
	public:
		SettingsForm(void)
		{
			InitializeComponent();
			//
			//TODO: �������� ��� ������������
			//
		}

	protected:
		/// <summary>
		/// ���������� ��� ������������ �������.
		/// </summary>
		~SettingsForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Panel^  panel1;
	protected: 
	private: System::Windows::Forms::Button^  bCancel;
	private: System::Windows::Forms::Button^  bOk;
	private: System::Windows::Forms::TabControl^  tabControl1;
	private: System::Windows::Forms::TabPage^  tbBooks;
	private: System::Windows::Forms::GroupBox^  groupBox2;
	private: System::Windows::Forms::Button^  bEditBook;

	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::Button^  bAddBook;
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::Label^  label1;
	private: System::Windows::Forms::DataGridView^  dataGridView1;
	private: System::Windows::Forms::TabPage^  tpSystems;
	private: System::Windows::Forms::GroupBox^  groupBox3;
	private: System::Windows::Forms::Button^  bEditSystem;

	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  textBox3;
	private: System::Windows::Forms::GroupBox^  groupBox4;
	private: System::Windows::Forms::Button^  bAddSystem;

	private: System::Windows::Forms::Label^  label5;
	private: System::Windows::Forms::TextBox^  textBox4;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::DataGridView^  dataGridView2;
	private: System::Windows::Forms::TabPage^  tpIntegrationSchemas;
	private: System::Windows::Forms::Button^  bAddSchema;

	private: System::Windows::Forms::Label^  label7;
	private: System::Windows::Forms::DataGridView^  dataGridView3;
	private: System::Windows::Forms::Button^  bEditSchema;

	private:
		/// <summary>
		/// ��������� ���������� ������������.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// ������������ ����� ��� ��������� ������������ - �� ���������
		/// ���������� ������� ������ ��� ������ ��������� ����.
		/// </summary>
		void InitializeComponent(void)
		{
			this->panel1 = (gcnew System::Windows::Forms::Panel());
			this->bCancel = (gcnew System::Windows::Forms::Button());
			this->bOk = (gcnew System::Windows::Forms::Button());
			this->tabControl1 = (gcnew System::Windows::Forms::TabControl());
			this->tbBooks = (gcnew System::Windows::Forms::TabPage());
			this->groupBox2 = (gcnew System::Windows::Forms::GroupBox());
			this->bEditBook = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->bAddBook = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->tpSystems = (gcnew System::Windows::Forms::TabPage());
			this->groupBox3 = (gcnew System::Windows::Forms::GroupBox());
			this->bEditSystem = (gcnew System::Windows::Forms::Button());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->textBox3 = (gcnew System::Windows::Forms::TextBox());
			this->groupBox4 = (gcnew System::Windows::Forms::GroupBox());
			this->bAddSystem = (gcnew System::Windows::Forms::Button());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->textBox4 = (gcnew System::Windows::Forms::TextBox());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->dataGridView2 = (gcnew System::Windows::Forms::DataGridView());
			this->tpIntegrationSchemas = (gcnew System::Windows::Forms::TabPage());
			this->dataGridView3 = (gcnew System::Windows::Forms::DataGridView());
			this->label7 = (gcnew System::Windows::Forms::Label());
			this->bAddSchema = (gcnew System::Windows::Forms::Button());
			this->bEditSchema = (gcnew System::Windows::Forms::Button());
			this->panel1->SuspendLayout();
			this->tabControl1->SuspendLayout();
			this->tbBooks->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox1->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->BeginInit();
			this->tpSystems->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->groupBox4->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView2))->BeginInit();
			this->tpIntegrationSchemas->SuspendLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView3))->BeginInit();
			this->SuspendLayout();
			// 
			// panel1
			// 
			this->panel1->Controls->Add(this->bCancel);
			this->panel1->Controls->Add(this->bOk);
			this->panel1->Dock = System::Windows::Forms::DockStyle::Bottom;
			this->panel1->Location = System::Drawing::Point(0, 294);
			this->panel1->Name = L"panel1";
			this->panel1->Size = System::Drawing::Size(737, 57);
			this->panel1->TabIndex = 1;
			// 
			// bCancel
			// 
			this->bCancel->BackColor = System::Drawing::Color::GhostWhite;
			this->bCancel->Location = System::Drawing::Point(650, 16);
			this->bCancel->Name = L"bCancel";
			this->bCancel->Size = System::Drawing::Size(75, 23);
			this->bCancel->TabIndex = 1;
			this->bCancel->Text = L"������";
			this->bCancel->UseVisualStyleBackColor = false;
			// 
			// bOk
			// 
			this->bOk->BackColor = System::Drawing::Color::GhostWhite;
			this->bOk->Location = System::Drawing::Point(559, 16);
			this->bOk->Name = L"bOk";
			this->bOk->Size = System::Drawing::Size(75, 23);
			this->bOk->TabIndex = 0;
			this->bOk->Text = L"��";
			this->bOk->UseVisualStyleBackColor = false;
			// 
			// tabControl1
			// 
			this->tabControl1->Controls->Add(this->tbBooks);
			this->tabControl1->Controls->Add(this->tpSystems);
			this->tabControl1->Controls->Add(this->tpIntegrationSchemas);
			this->tabControl1->Dock = System::Windows::Forms::DockStyle::Fill;
			this->tabControl1->Location = System::Drawing::Point(0, 0);
			this->tabControl1->Name = L"tabControl1";
			this->tabControl1->Padding = System::Drawing::Point(10, 5);
			this->tabControl1->SelectedIndex = 0;
			this->tabControl1->Size = System::Drawing::Size(737, 294);
			this->tabControl1->TabIndex = 2;
			// 
			// tbBooks
			// 
			this->tbBooks->BackColor = System::Drawing::Color::GhostWhite;
			this->tbBooks->Controls->Add(this->groupBox2);
			this->tbBooks->Controls->Add(this->groupBox1);
			this->tbBooks->Controls->Add(this->label1);
			this->tbBooks->Controls->Add(this->dataGridView1);
			this->tbBooks->Location = System::Drawing::Point(4, 26);
			this->tbBooks->Name = L"tbBooks";
			this->tbBooks->Padding = System::Windows::Forms::Padding(3);
			this->tbBooks->Size = System::Drawing::Size(729, 264);
			this->tbBooks->TabIndex = 0;
			this->tbBooks->Text = L"�����������";
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->bEditBook);
			this->groupBox2->Controls->Add(this->label3);
			this->groupBox2->Controls->Add(this->textBox2);
			this->groupBox2->Location = System::Drawing::Point(363, 141);
			this->groupBox2->Name = L"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(349, 105);
			this->groupBox2->TabIndex = 3;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = L"�������� ����������";
			// 
			// bEditBook
			// 
			this->bEditBook->BackColor = System::Drawing::Color::GhostWhite;
			this->bEditBook->Enabled = false;
			this->bEditBook->Location = System::Drawing::Point(127, 58);
			this->bEditBook->Name = L"bEditBook";
			this->bEditBook->Size = System::Drawing::Size(103, 37);
			this->bEditBook->TabIndex = 2;
			this->bEditBook->Text = L"��������";
			this->bEditBook->UseVisualStyleBackColor = false;
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(24, 16);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(83, 13);
			this->label3->TabIndex = 1;
			this->label3->Text = L"������������";
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(27, 32);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(300, 20);
			this->textBox2->TabIndex = 0;
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->bAddBook);
			this->groupBox1->Controls->Add(this->label2);
			this->groupBox1->Controls->Add(this->textBox1);
			this->groupBox1->Location = System::Drawing::Point(363, 21);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(349, 114);
			this->groupBox1->TabIndex = 2;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = L"�������� ����������";
			// 
			// bAddBook
			// 
			this->bAddBook->BackColor = System::Drawing::Color::GhostWhite;
			this->bAddBook->Enabled = false;
			this->bAddBook->Location = System::Drawing::Point(127, 61);
			this->bAddBook->Name = L"bAddBook";
			this->bAddBook->Size = System::Drawing::Size(103, 37);
			this->bAddBook->TabIndex = 2;
			this->bAddBook->Text = L"��������";
			this->bAddBook->UseVisualStyleBackColor = false;
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(24, 19);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(83, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"������������";
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(27, 35);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(300, 20);
			this->textBox1->TabIndex = 0;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(19, 21);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(135, 13);
			this->label1->TabIndex = 1;
			this->label1->Text = L"��������� �����������:";
			// 
			// dataGridView1
			// 
			this->dataGridView1->BackgroundColor = System::Drawing::Color::GhostWhite;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Location = System::Drawing::Point(19, 40);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->ReadOnly = true;
			this->dataGridView1->Size = System::Drawing::Size(324, 206);
			this->dataGridView1->TabIndex = 0;
			// 
			// tpSystems
			// 
			this->tpSystems->BackColor = System::Drawing::Color::GhostWhite;
			this->tpSystems->Controls->Add(this->groupBox3);
			this->tpSystems->Controls->Add(this->groupBox4);
			this->tpSystems->Controls->Add(this->label6);
			this->tpSystems->Controls->Add(this->dataGridView2);
			this->tpSystems->Location = System::Drawing::Point(4, 26);
			this->tpSystems->Name = L"tpSystems";
			this->tpSystems->Padding = System::Windows::Forms::Padding(3);
			this->tpSystems->Size = System::Drawing::Size(729, 264);
			this->tpSystems->TabIndex = 1;
			this->tpSystems->Text = L"�������";
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->bEditSystem);
			this->groupBox3->Controls->Add(this->label4);
			this->groupBox3->Controls->Add(this->textBox3);
			this->groupBox3->Location = System::Drawing::Point(362, 142);
			this->groupBox3->Name = L"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(349, 105);
			this->groupBox3->TabIndex = 7;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = L"�������� �������";
			// 
			// bEditSystem
			// 
			this->bEditSystem->BackColor = System::Drawing::Color::GhostWhite;
			this->bEditSystem->Enabled = false;
			this->bEditSystem->Location = System::Drawing::Point(127, 58);
			this->bEditSystem->Name = L"bEditSystem";
			this->bEditSystem->Size = System::Drawing::Size(103, 37);
			this->bEditSystem->TabIndex = 2;
			this->bEditSystem->Text = L"��������";
			this->bEditSystem->UseVisualStyleBackColor = false;
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(24, 16);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(83, 13);
			this->label4->TabIndex = 1;
			this->label4->Text = L"������������";
			// 
			// textBox3
			// 
			this->textBox3->Location = System::Drawing::Point(27, 32);
			this->textBox3->Name = L"textBox3";
			this->textBox3->Size = System::Drawing::Size(300, 20);
			this->textBox3->TabIndex = 0;
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->bAddSystem);
			this->groupBox4->Controls->Add(this->label5);
			this->groupBox4->Controls->Add(this->textBox4);
			this->groupBox4->Location = System::Drawing::Point(362, 22);
			this->groupBox4->Name = L"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(349, 114);
			this->groupBox4->TabIndex = 6;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = L"�������� �������";
			// 
			// bAddSystem
			// 
			this->bAddSystem->BackColor = System::Drawing::Color::GhostWhite;
			this->bAddSystem->Enabled = false;
			this->bAddSystem->Location = System::Drawing::Point(127, 61);
			this->bAddSystem->Name = L"bAddSystem";
			this->bAddSystem->Size = System::Drawing::Size(103, 37);
			this->bAddSystem->TabIndex = 2;
			this->bAddSystem->Text = L"��������";
			this->bAddSystem->UseVisualStyleBackColor = false;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(24, 19);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(83, 13);
			this->label5->TabIndex = 1;
			this->label5->Text = L"������������";
			// 
			// textBox4
			// 
			this->textBox4->Location = System::Drawing::Point(27, 35);
			this->textBox4->Name = L"textBox4";
			this->textBox4->Size = System::Drawing::Size(300, 20);
			this->textBox4->TabIndex = 0;
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(18, 22);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(115, 13);
			this->label6->TabIndex = 5;
			this->label6->Text = L"��������� �������:";
			// 
			// dataGridView2
			// 
			this->dataGridView2->BackgroundColor = System::Drawing::Color::GhostWhite;
			this->dataGridView2->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView2->Location = System::Drawing::Point(18, 41);
			this->dataGridView2->Name = L"dataGridView2";
			this->dataGridView2->ReadOnly = true;
			this->dataGridView2->Size = System::Drawing::Size(324, 206);
			this->dataGridView2->TabIndex = 4;
			// 
			// tpIntegrationSchemas
			// 
			this->tpIntegrationSchemas->BackColor = System::Drawing::Color::GhostWhite;
			this->tpIntegrationSchemas->Controls->Add(this->bEditSchema);
			this->tpIntegrationSchemas->Controls->Add(this->bAddSchema);
			this->tpIntegrationSchemas->Controls->Add(this->label7);
			this->tpIntegrationSchemas->Controls->Add(this->dataGridView3);
			this->tpIntegrationSchemas->Location = System::Drawing::Point(4, 26);
			this->tpIntegrationSchemas->Name = L"tpIntegrationSchemas";
			this->tpIntegrationSchemas->Padding = System::Windows::Forms::Padding(3);
			this->tpIntegrationSchemas->Size = System::Drawing::Size(729, 264);
			this->tpIntegrationSchemas->TabIndex = 2;
			this->tpIntegrationSchemas->Text = L"�������������� �����";
			// 
			// dataGridView3
			// 
			this->dataGridView3->BackgroundColor = System::Drawing::Color::GhostWhite;
			this->dataGridView3->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView3->Location = System::Drawing::Point(25, 42);
			this->dataGridView3->Name = L"dataGridView3";
			this->dataGridView3->Size = System::Drawing::Size(675, 199);
			this->dataGridView3->TabIndex = 0;
			// 
			// label7
			// 
			this->label7->AutoSize = true;
			this->label7->Location = System::Drawing::Point(22, 15);
			this->label7->Name = L"label7";
			this->label7->Size = System::Drawing::Size(103, 13);
			this->label7->TabIndex = 1;
			this->label7->Text = L"��������� �����:";
			// 
			// bAddSchema
			// 
			this->bAddSchema->Location = System::Drawing::Point(625, 10);
			this->bAddSchema->Name = L"bAddSchema";
			this->bAddSchema->Size = System::Drawing::Size(75, 23);
			this->bAddSchema->TabIndex = 2;
			this->bAddSchema->Text = L"��������";
			this->bAddSchema->UseVisualStyleBackColor = true;
			// 
			// bEditSchema
			// 
			this->bEditSchema->Location = System::Drawing::Point(533, 10);
			this->bEditSchema->Name = L"bEditSchema";
			this->bEditSchema->Size = System::Drawing::Size(75, 23);
			this->bEditSchema->TabIndex = 3;
			this->bEditSchema->Text = L"��������";
			this->bEditSchema->UseVisualStyleBackColor = true;
			// 
			// SettingsForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::GhostWhite;
			this->ClientSize = System::Drawing::Size(737, 351);
			this->Controls->Add(this->tabControl1);
			this->Controls->Add(this->panel1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedSingle;
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"SettingsForm";
			this->Text = L"SettingsForm";
			this->TopMost = true;
			this->panel1->ResumeLayout(false);
			this->tabControl1->ResumeLayout(false);
			this->tbBooks->ResumeLayout(false);
			this->tbBooks->PerformLayout();
			this->groupBox2->ResumeLayout(false);
			this->groupBox2->PerformLayout();
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->EndInit();
			this->tpSystems->ResumeLayout(false);
			this->tpSystems->PerformLayout();
			this->groupBox3->ResumeLayout(false);
			this->groupBox3->PerformLayout();
			this->groupBox4->ResumeLayout(false);
			this->groupBox4->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView2))->EndInit();
			this->tpIntegrationSchemas->ResumeLayout(false);
			this->tpIntegrationSchemas->PerformLayout();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView3))->EndInit();
			this->ResumeLayout(false);

		}
#pragma endregion

};
}
